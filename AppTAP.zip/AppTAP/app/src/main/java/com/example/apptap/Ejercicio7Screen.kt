package com.example.apptap.ui.ejercicios // Asegúrate de que el paquete sea el correcto

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
// Importa la función contentColorFor desde tu archivo de utilidades
import com.example.apptap.ui.ejercicios.contentColorFor // Asegúrate de que esta sea la ruta correcta

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Ejercicio7Screen(navController: NavController) {
    var currentNames by remember { mutableStateOf(emptyList<String>()) }

    var selectedName by remember { mutableStateOf<String?>(null) }
    // Estado para el mensaje de resultado (lblResultado en Swing)
    var resultMessage by remember { mutableStateOf("Haz clic en un nombre para verlo aquí.") }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Ejercicio 7: Listas Dinámicas") })
        },
        content = { paddingValues ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // --- Botones para Cargar Cursos ---
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Botón Curso 1
                    Button(
                        onClick = {
                            currentNames = listOf("Juan", "Maria", "Luis")
                            selectedName = null
                            resultMessage = "Lista 'Curso 1' cargada."
                        },
                        modifier = Modifier.weight(1f).height(50.dp).padding(horizontal = 4.dp),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("Curso 1")
                    }

                    // Botón Curso 2
                    Button(
                        onClick = {
                            currentNames = listOf("Ana", "Marta", "Jose")
                            selectedName = null
                            resultMessage = "Lista 'Curso 2' cargada."
                        },
                        modifier = Modifier.weight(1f).height(50.dp).padding(horizontal = 4.dp),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("Curso 2")
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // --- Botón Vaciar ---
                Button(
                    onClick = {
                        currentNames = emptyList()
                        selectedName = null
                        resultMessage = "Lista vaciada."
                    },
                    modifier = Modifier.fillMaxWidth(0.6f).height(50.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Vaciar Lista")
                }

                Spacer(modifier = Modifier.height(20.dp))

                Text(
                    text = "Nombres en la lista:",
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.align(Alignment.Start)
                )
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth(0.8f)
                        .heightIn(min = 100.dp, max = 300.dp)
                        .background(
                            MaterialTheme.colorScheme.surfaceVariant,
                            RoundedCornerShape(8.dp)
                        )
                        .padding(8.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    if (currentNames.isEmpty()) {
                        item {
                            Text(
                                text = "La lista está vacía. Carga un curso.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                                modifier = Modifier.fillMaxWidth().padding(vertical = 20.dp),
                                textAlign = TextAlign.Center
                            )
                        }
                    } else {
                        items(currentNames) { name ->
                            val isSelected = name == selectedName
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        selectedName = name
                                        resultMessage = "Has seleccionado: $name"
                                    },
                                shape = RoundedCornerShape(4.dp),
                                color = if (isSelected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent,
                                tonalElevation = if (isSelected) 4.dp else 0.dp
                            ) {
                                Text(
                                    text = name,
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(12.dp)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                Text(
                    text = resultMessage,
                    style = MaterialTheme.typography.titleLarge.copy(
                        color = if (selectedName != null) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                    ),
                    modifier = Modifier.padding(horizontal = 8.dp)
                )

                Spacer(modifier = Modifier.weight(1f))

                Button(
                    onClick = {
                        navController.navigate("menu") {
                            popUpTo("menu") { inclusive = true }
                        }
                    },
                    modifier = Modifier.fillMaxWidth(0.6f)
                ) {
                    Text("Volver al Menú")
                }
            }
        }
    )
}