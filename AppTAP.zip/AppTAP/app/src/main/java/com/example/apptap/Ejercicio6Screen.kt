package com.example.apptap.ui.ejercicios // Asegúrate de que el paquete sea el correcto

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
// Importa la función contentColorFor desde tu archivo de utilidades
import com.example.apptap.ui.ejercicios.contentColorFor // Asegúrate de que esta sea la ruta correcta

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Ejercicio6Screen(navController: NavController) {
    var carCount by remember { mutableStateOf(0) }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Ejercicio 5: Contador de Vehículos") })
        },
        content = { paddingValues ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {

                Text(
                    text = "Vehículos en el Garaje:",
                    style = MaterialTheme.typography.headlineMedium,
                    modifier = Modifier.padding(bottom = 20.dp)
                )

                // --- Visualización del Contador ---
                Surface(
                    modifier = Modifier
                        .size(120.dp)
                        .padding(8.dp),
                    shape = RoundedCornerShape(percent = 50),
                    color = MaterialTheme.colorScheme.primaryContainer,
                    tonalElevation = 6.dp
                ) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier.fillMaxSize()
                    ) {
                        Text(
                            text = carCount.toString(),
                            style = MaterialTheme.typography.displayLarge.copy(
                                fontSize = 60.sp,
                                fontWeight = FontWeight.ExtraBold
                            ),
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                }

                Spacer(modifier = Modifier.height(40.dp))

                // --- Fila de Botones de Control ---
                Row(
                    modifier = Modifier.fillMaxWidth(0.8f), // Ancho de la fila de botones
                    horizontalArrangement = Arrangement.SpaceAround, // Distribuye los botones equitativamente
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Botón "Entró"
                    Button(
                        onClick = { carCount++ }, // Incrementa el contador
                        modifier = Modifier.weight(1f).height(55.dp).padding(horizontal = 4.dp), // Pesa y padding
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Entró")
                    }

                    // Botón "Salió"
                    Button(
                        onClick = { if (carCount > 0) carCount-- }, // Decrementa si es mayor que 0
                        modifier = Modifier.weight(1f).height(55.dp).padding(horizontal = 4.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary) // Color diferente
                    ) {
                        Text("Salió")
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Botón "Reiniciar" (separado para mayor prominencia)
                Button(
                    onClick = { carCount = 0 }, // Resetea el contador a 0
                    modifier = Modifier.fillMaxWidth(0.5f).height(55.dp), // Más estrecho
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error) // Color de error
                ) {
                    Text("Reiniciar")
                }

                Spacer(modifier = Modifier.weight(1f)) // Empuja el botón de volver al final

                // --- Botón de Volver al Menú ---
                Button(
                    onClick = {
                        navController.navigate("menu") {
                            popUpTo("menu") { inclusive = true }
                        }
                    },
                    modifier = Modifier.fillMaxWidth(0.6f)
                ) {
                    Text("Volver al Menú")
                }
            }
        }
    )
}