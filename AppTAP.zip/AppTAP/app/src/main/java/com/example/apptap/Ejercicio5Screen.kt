package com.example.apptap.ui.ejercicios

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn // Para listas eficientes
import androidx.compose.foundation.lazy.items // Para iterar sobre ítems en LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
// Importa la función contentColorFor desde tu archivo de utilidades


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Ejercicio5Screen(navController: NavController) {
    val colors = listOf("Rojo", "Verde", "Azul", "Amarillo", "Púrpura", "Naranja")
    var selectedColorName by remember { mutableStateOf<String?>(null) }


    var resultMessage by remember { mutableStateOf("Selecciona un color de la lista.") }


    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Ejercicio 5 = Selector de color ") })
        },
        content = { paddingValues ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = "Elige un color de la lista ;" ,
                    style = MaterialTheme.typography.headlineSmall,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth(0.8f)
                        .height(250.dp)
                        .background(
                            MaterialTheme.colorScheme.surfaceVariant,
                            RoundedCornerShape(8.dp)
                        )
                        .padding(8.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    items(colors) { colorName ->

                        val isSelected = colorName == selectedColorName
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    selectedColorName = colorName
                                },
                            shape = RoundedCornerShape(4.dp),
                            color = if (isSelected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent,
                            tonalElevation = if (isSelected) 4.dp else 0.dp // Elevación si está seleccionado
                        ) {
                            Text(
                                text = colorName,
                                style = MaterialTheme.typography.bodyLarge,
                                color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(12.dp) // Padding dentro de cada ítem de texto
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = {
                        resultMessage = if (selectedColorName == null) {
                            "No hay un color seleccionado."
                        } else {
                            "El color seleccionado es: $selectedColorName"
                        }
                    },
                    modifier = Modifier.fillMaxWidth(0.6f), // Ancho del botón Aceptar
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("Aceptar Selección")
                }

                Spacer(modifier = Modifier.height(20.dp))
                Text(
                    text = resultMessage,
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.padding(horizontal = 8.dp)
                )

                Spacer(modifier = Modifier.weight(1f))
                Button(
                    onClick = {
                        navController.navigate("menu") {
                            popUpTo("menu") { inclusive = true }
                        }
                    },
                    modifier = Modifier.fillMaxWidth(0.6f)
                ) {
                    Text("Volver al Menú")
                }
            }
        }
    )
}