package com.example.apptap.ui.ejercicios

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

import androidx.compose.runtime.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Ejercicio2Screen(navController: NavController) {
    var items by remember { mutableStateOf(listOf<String>()) }
    var expanded by remember { mutableStateOf(false) }
    var selectedItem by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Ejercicio 2: Selección de Números") })
        },
        content = { paddingValues ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    Button(onClick = {
                        items = (0..8 step 2).map { "N-$it" }
                        selectedItem = ""
                    }) {
                        Text("Pares")
                    }
                    Button(onClick = {
                        items = (1..9 step 2).map { "N-$it" }
                        selectedItem = ""
                    }) {
                        Text("Impares")
                    }
                    Button(onClick = {
                        items = emptyList()
                        selectedItem = ""
                    }) {
                        Text("Vaciar")
                    }
                }
                     ExposedDropdownMenuBox(
                    expanded = expanded,
                    onExpandedChange = { expanded = !expanded },
                    modifier = Modifier.fillMaxWidth(0.8f)
                ) {
                    TextField(
                        readOnly = true,
                        value = selectedItem,
                        onValueChange = {},
                        label = { Text("Selecciona un número") },
                        modifier = Modifier
                            .menuAnchor()
                            .fillMaxWidth()
                    )
                    ExposedDropdownMenu(
                        expanded = expanded,
                        onDismissRequest = { expanded = false }
                    ) {
                        items.forEach { label ->
                            DropdownMenuItem(
                                text = { Text(label) },
                                onClick = {
                                    selectedItem = label
                                    expanded = false
                                }
                            )
                        }
                    }
                }
                if (selectedItem.isNotEmpty()) {
                    Text(
                        text = "Seleccionaste: $selectedItem",
                        style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier.padding(top = 10.dp)
                    )
                }

               Spacer(modifier = Modifier.height(20.dp))
                Text(
                    text = "Este es el Ejercicio 2 de Programación.",
                    style = MaterialTheme.typography.bodyLarge,
                    modifier = Modifier.padding(horizontal = 8.dp)
                )
                Text(
                    text = "Puedes usar la lista desplegable para generar y seleccionar números.",
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(horizontal = 8.dp)
                )

                Spacer(modifier = Modifier.height(30.dp))

                Button(
                    onClick = {
                        navController.navigate("menu") {
                            popUpTo("menu") { inclusive = true }
                        }
                    },
                    modifier = Modifier.fillMaxWidth(0.6f)
                ) {
                    Text("Volver al Menú")
                }
            }
        }
    )
}