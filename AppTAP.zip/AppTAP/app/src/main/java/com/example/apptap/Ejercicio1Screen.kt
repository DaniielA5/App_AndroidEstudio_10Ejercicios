package com.example.apptap.ui.ejercicios

import android.inputmethodservice.Keyboard.Row
import androidx.compose.animation.expandVertically
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.compose.runtime.*




@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Ejercicio1Screen(navController: NavController) {
    var perroChecked by remember { mutableStateOf(false) }
    var gatoChecked by remember { mutableStateOf(false) }
    var ratonChecked by remember { mutableStateOf(false) }
    var resultado by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Ejercicio 1") })
        },
        content = { padding ->
            Column(
                modifier = Modifier
                    .padding(padding)
                    .padding(16.dp)
                    .fillMaxSize(),
                verticalArrangement = Arrangement.Top,
                horizontalAlignment = Alignment.Start
            ) {
                Text("Selecciona los animales:")

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = perroChecked, onCheckedChange = { perroChecked = it })
                    Text("Perro")
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = gatoChecked, onCheckedChange = { gatoChecked = it })
                    Text("Gato")
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = ratonChecked, onCheckedChange = { ratonChecked = it })
                    Text("Ratón")
                }
                Spacer(modifier = Modifier.height(16.dp))

                Button(onClick = {
                    var mensaje = "Animales elegidos: "
                    if (perroChecked) mensaje += "Perro - "
                    if (gatoChecked) mensaje += "Gato - "
                    if (ratonChecked) mensaje += "Ratón - "
                    resultado = mensaje
                }) {
                    Text("Aceptar")
                }
                Spacer(modifier = Modifier.height(16.dp))
                Text(resultado)

                Text("--------------------------------")
                Button(onClick = {
                    navController.navigate("menu") {
                        popUpTo("menu") { inclusive = true }
                    }
                }) {
                    Text("Volver al Menú")
                }
            }

        }
    )
}