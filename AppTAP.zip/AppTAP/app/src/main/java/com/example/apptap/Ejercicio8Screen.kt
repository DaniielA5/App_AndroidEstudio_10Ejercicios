package com.example.apptap.ui.ejercicios // Asegúrate de que el paquete sea el correcto

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MoreVert // Para el menú de opciones
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType // Para teclado numérico
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
// Importa la función contentColorFor desde tu archivo de utilidades si la necesitas aquí
// import com.example.apptap.ui.ejercicios.contentColorFor

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Ejercicio8Screen(navController: NavController) {
    // Estados para los valores de los números de entrada
    var numero1 by remember { mutableStateOf("") }
    var numero2 by remember { mutableStateOf("") }
    // Estado para el resultado de la operación
    var resultado by remember { mutableStateOf("0") }
    // Estado para controlar la visibilidad del menú en la TopAppBar
    var showMenu by remember { mutableStateOf(false) }

    // Función para realizar la suma
    fun sumar() {
        try {
            val a = numero1.toInt()
            val b = numero2.toInt()
            resultado = (a + b).toString()
        } catch (e: NumberFormatException) {
            resultado = "Error: Números inválidos" // Manejo de error para entradas no numéricas
        }
    }

    // Función para realizar la resta
    fun restar() {
        try {
            val a = numero1.toInt()
            val b = numero2.toInt()
            resultado = (a - b).toString()
        } catch (e: NumberFormatException) {
            resultado = "Error: Números inválidos"
        }
    }

    fun borrar() {
        numero1 = ""
        numero2 = ""
        resultado = "0"
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Ejercicio 7: Calculadora Básica") },
                actions = {
                    IconButton(onClick = { showMenu = !showMenu }) {
                        Icon(Icons.Default.MoreVert, contentDescription = "Menú de Operaciones")
                    }
                    DropdownMenu(
                        expanded = showMenu,
                        onDismissRequest = { showMenu = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("Sumar") },
                            onClick = {
                                sumar()
                                showMenu = false
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Restar") },
                            onClick = {
                                restar()
                                showMenu = false
                            }
                        )
                        Divider() // Separador visual en el menú
                        DropdownMenuItem(
                            text = { Text("Borrar") },
                            onClick = {
                                borrar()
                                showMenu = false
                            }
                        )
                    }
                }
            )
        },
        content = { paddingValues ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(20.dp, Alignment.CenterVertically) // Centra verticalmente y espacia
            ) {
                OutlinedTextField(
                    value = numero1,
                    onValueChange = { newValue -> numero1 = newValue.filter { it.isDigit() || it == '-' } }, // Solo permite dígitos y guión para negativos
                    label = { Text("Número 1") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(0.8f)
                )
                OutlinedTextField(
                    value = numero2,
                    onValueChange = { newValue -> numero2 = newValue.filter { it.isDigit() || it == '-' } }, // Solo permite dígitos y guión
                    label = { Text("Número 2") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(0.8f)
                )

                Spacer(modifier = Modifier.height(30.dp))

                // --- Fila de Botones de Operación ---
                Row(
                    modifier = Modifier.fillMaxWidth(0.8f),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Botón Sumar (btnSumar)
                    Button(
                        onClick = { sumar() },
                        modifier = Modifier.weight(1f).height(55.dp).padding(horizontal = 4.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Sumar")
                    }

                    // Botón Restar (btnRestar)
                    Button(
                        onClick = { restar() },
                        modifier = Modifier.weight(1f).height(55.dp).padding(horizontal = 4.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Restar")
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = { borrar() },
                    modifier = Modifier.fillMaxWidth(0.6f).height(55.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.tertiary) // Otro color para diferenciar
                ) {
                    Text("Borrar")
                }

                Spacer(modifier = Modifier.height(30.dp))

                Text(
                    text = "Resultado: $resultado",
                    style = MaterialTheme.typography.displaySmall.copy( // Estilo grande para el resultado
                        fontSize = 40.sp,
                        fontWeight = FontWeight.Bold
                    ),
                    color = MaterialTheme.colorScheme.primary, // Color principal para el resultado
                    modifier = Modifier.padding(horizontal = 16.dp)
                )

                Spacer(modifier = Modifier.weight(1f)) // Empuja el botón de volver al final

                Button(
                    onClick = {
                        navController.navigate("menu") {
                            popUpTo("menu") { inclusive = true }
                        }
                    },
                    modifier = Modifier.fillMaxWidth(0.6f)
                ) {
                    Text("Volver al Menú")
                }
            }
        }
    )
}