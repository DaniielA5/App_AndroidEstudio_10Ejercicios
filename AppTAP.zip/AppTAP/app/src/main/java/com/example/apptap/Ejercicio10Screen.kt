package com.example.apptap.ui.ejercicios // Asegúrate de que el paquete sea el correcto

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
// Importa la función contentColorFor si la necesitas aquí
// import com.example.apptap.ui.ejercicios.contentColorFor

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Ejercicio10Screen(navController: NavController) {
    val colors = listOf("Rojo", "Verde", "Azul", "Amarillo", "Púrpura", "Naranja")

    var selectedColor by remember { mutableStateOf(colors[0]) }
    var expanded by remember { mutableStateOf(false) }
    var resultMessage by remember { mutableStateOf("El color elegido es: ${selectedColor}") }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Ejercicio 9: Selector Desplegable") })
        },
        content = { paddingValues ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues) // Aplica el padding del Scaffold
                    .padding(24.dp), // Padding interno para el contenido
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(30.dp, Alignment.CenterVertically) // Centra verticalmente y espacia
            ) {
                //
                Text(
                    text = "Selecciona un color de la lista:",
                    style = MaterialTheme.typography.headlineSmall,
                    modifier = Modifier.padding(bottom = 10.dp)
                )

                ExposedDropdownMenuBox(
                    expanded = expanded,
                    onExpandedChange = { expanded = !expanded }, // Abre/Cierra el desplegable
                    modifier = Modifier.fillMaxWidth(0.7f) // Controla el ancho del componente
                ) {
                    TextField(
                        readOnly = true, // No permite escribir directamente
                        value = selectedColor, // Muestra el color seleccionado
                        onValueChange = { }, // No se usa porque es readOnly
                        label = { Text("Elige un color") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) }, // Icono de flecha
                        modifier = Modifier.menuAnchor().fillMaxWidth() // Necesario para que el TextField actúe como ancla del menú
                    )

                    // El menú desplegable con las opciones
                    ExposedDropdownMenu(
                        expanded = expanded,
                        onDismissRequest = { expanded = false } // Cierra el menú si se hace clic fuera
                    ) {
                        colors.forEach { color ->
                            DropdownMenuItem(
                                text = { Text(color) },
                                onClick = {
                                    selectedColor = color // Actualiza el color seleccionado
                                    resultMessage = "El color elegido es: $selectedColor" // Actualiza el mensaje
                                    expanded = false // Cierra el menú al seleccionar
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(30.dp))

                Text(
                    text = resultMessage,
                    style = MaterialTheme.typography.titleLarge.copy(
                        color = MaterialTheme.colorScheme.primary,
                        fontSize = 24.sp
                    ),
                    modifier = Modifier.padding(horizontal = 16.dp)
                )

                Spacer(modifier = Modifier.weight(1f))

                Button(
                    onClick = {
                        navController.navigate("menu") {
                            popUpTo("menu") { inclusive = true }
                        }
                    },
                    modifier = Modifier.fillMaxWidth(0.6f)
                ) {
                    Text("Volver al Menú")
                }
            }
        }
    )
}