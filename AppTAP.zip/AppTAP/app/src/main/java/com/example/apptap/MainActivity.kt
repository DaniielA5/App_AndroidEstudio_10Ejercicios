package com.example.apptap

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.apptap.ui.theme.AppTAPTheme
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.NavHostController
import androidx.navigation.compose.rememberNavController
import com.example.apptap.ui.ejercicios.Ejercicio10Screen
import com.example.apptap.ui.ejercicios.Ejercicio1Screen
import com.example.apptap.ui.ejercicios.Ejercicio2Screen
import com.example.apptap.ui.ejercicios.Ejercicio3Screen
import com.example.apptap.ui.ejercicios.Ejercicio4Screen
import com.example.apptap.ui.ejercicios.Ejercicio5Screen
import com.example.apptap.ui.ejercicios.Ejercicio6Screen
import com.example.apptap.ui.ejercicios.Ejercicio7Screen
import com.example.apptap.ui.ejercicios.Ejercicio8Screen
import com.example.apptap.ui.ejercicios.Ejercicio9Screen


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AppTAPTheme {
                val navController = rememberNavController()
                NavHost(navController = navController, startDestination = "login") {
                    composable("login") {
                        LoginScreen(navController)
                    }
                    composable("menu") {
                        MenuScreen(navController = navController)
                    }

                    // Rutas para los 10 ejercicios
                    composable("ejercicio1") { Ejercicio1Screen(navController) }
                    composable("ejercicio2") { Ejercicio2Screen(navController) }
                    composable("ejercicio3") { Ejercicio3Screen(navController) }
                    composable("ejercicio4") { Ejercicio4Screen(navController) }
                    composable("ejercicio5") { Ejercicio5Screen(navController) }
                    composable("ejercicio6") { Ejercicio6Screen(navController) }
                    composable("ejercicio7") { Ejercicio7Screen(navController) }
                    composable("ejercicio8") { Ejercicio8Screen(navController) }
                    composable("ejercicio9") { Ejercicio9Screen(navController) }
                    composable("ejercicio10") { Ejercicio10Screen(navController) }
                }
            }
        }
    }
}

@Composable
fun LoginScreen(navController: androidx.navigation.NavHostController) {
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFA8CBDE))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(
                painter = painterResource(id = R.drawable.ic_user),
                contentDescription = "User Icon",
                modifier = Modifier.size(100.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))

            TextField(
                value = username,
                onValueChange = { username = it },
                label = { Text("Usuario") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(8.dp))

            TextField(
                value = password,
                onValueChange = { password = it },
                label = { Text("Contraseña") },
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = {
                    if (username == "admin" && password == "1234") {
                        navController.navigate("menu")
                    } else {
                        message = "Usuario o contraseña incorrectos"
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF3F51B5), // Verde por ejemplo
                    contentColor = Color.White          // Letras blancas
                )
            ) {
                Text("Iniciar sesión")
            }


            Spacer(modifier = Modifier.height(16.dp))

            Text(text = message)
        }
    }
}


@Preview(showBackground = true, showSystemUi = true)
@Composable
fun LoginScreenPreview() {
    AppTAPTheme {
        LoginScreen(navController = rememberNavController())
    }
}

