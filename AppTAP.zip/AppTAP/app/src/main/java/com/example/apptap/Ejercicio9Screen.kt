package com.example.apptap.ui.ejercicios // Asegúrate de que el paquete sea el correcto

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
// Importa la función contentColorFor si la necesitas aquí para algún elemento específico
// import com.example.apptap.ui.ejercicios.contentColorFor

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Ejercicio9Screen(navController: NavController) {
    var selectedColorOption by remember { mutableStateOf<String?>(null) }

    var resultMessage by remember { mutableStateOf("Pulsa Aceptar para ver el color elegido.") }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Ejercicio 8: Selector de Color") })
        },
        content = { paddingValues ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues) // Aplica el padding del Scaffold
                    .padding(24.dp), // Padding interno para el contenido
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(20.dp, Alignment.CenterVertically) // Centra verticalmente y espacia
            ) {
                // --- Título/Instrucción ---
                Text(
                    text = "Selecciona tu color favorito:",
                    style = MaterialTheme.typography.headlineSmall,
                    modifier = Modifier.padding(bottom = 10.dp)
                )

                Column(
                    modifier = Modifier
                        .fillMaxWidth(0.6f)
                        .background(
                            MaterialTheme.colorScheme.surfaceVariant,
                            shape = MaterialTheme.shapes.medium
                        )
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    horizontalAlignment = Alignment.Start,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Radio Button para "Rojo"
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { selectedColorOption = "Rojo" },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = selectedColorOption == "Rojo",
                            onClick = { selectedColorOption = "Rojo" }
                        )
                        Text("Rojo", style = MaterialTheme.typography.bodyLarge)
                    }

                    // Radio Button para "Verde"
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { selectedColorOption = "Verde" },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = selectedColorOption == "Verde",
                            onClick = { selectedColorOption = "Verde" }
                        )
                        Text("Verde", style = MaterialTheme.typography.bodyLarge)
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { selectedColorOption = "Azul" },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = selectedColorOption == "Azul",
                            onClick = { selectedColorOption = "Azul" }
                        )
                        Text("Azul", style = MaterialTheme.typography.bodyLarge)
                    }
                }

                Spacer(modifier = Modifier.height(30.dp))
                Button(
                    onClick = {
                        // Lógica similar a btnAceptarActionPerformed
                        resultMessage = if (selectedColorOption == null) {
                            "No has seleccionado ningún color."
                        } else {
                            "Color elegido: ${selectedColorOption!!}"
                        }
                    },
                    modifier = Modifier.fillMaxWidth(0.5f).height(55.dp),
                    shape = MaterialTheme.shapes.medium // Utiliza la forma media del tema
                ) {
                    Text("Aceptar")
                }

                Spacer(modifier = Modifier.height(20.dp))

                // --- Resultado (lblResultado) ---
                Text(
                    text = resultMessage,
                    style = MaterialTheme.typography.titleLarge.copy(
                        color = MaterialTheme.colorScheme.primary // Color principal para el resultado
                    ),
                    modifier = Modifier.padding(horizontal = 16.dp)
                )

                Spacer(modifier = Modifier.weight(1f)) // Empuja el botón de volver al final

                // --- Botón de Volver al Menú ---
                Button(
                    onClick = {
                        navController.navigate("menu") {
                            popUpTo("menu") { inclusive = true }
                        }
                    },
                    modifier = Modifier.fillMaxWidth(0.6f)
                ) {
                    Text("Volver al Menú")
                }
            }
        }
    )
}