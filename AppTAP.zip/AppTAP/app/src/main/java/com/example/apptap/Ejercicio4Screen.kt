package com.example.apptap.ui.ejercicios

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.DpOffset
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.compose.runtime.Composable

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Ejercicio4Screen(navController: NavController) {
    var backgroundColor by remember { mutableStateOf(Color.White) }
    var showMenu by remember { mutableStateOf(false) }
    var tapOffset by remember { mutableStateOf(Offset.Zero) }
    Scaffold(
        topBar = {

            TopAppBar(title = { Text("Ejercicio 4: Menú Contextual") }) // Título corregido
        },
        content = { paddingValues ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .background(backgroundColor)
                    .pointerInput(Unit) {
                        detectTapGestures(
                            onLongPress = { offset: Offset ->
                                tapOffset = offset
                                showMenu = true
                            }
                        )
                    }
            ) {
                if (showMenu) {
                    DropdownMenu(
                        expanded = true,
                        offset = DpOffset(tapOffset.x.dp, tapOffset.y.dp),
                        onDismissRequest = { showMenu = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("Rojo") },
                            onClick = {
                                backgroundColor = Color.Red
                                showMenu = false // Oculta el menú al seleccionar una opción
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Azul") },
                            onClick = {
                                backgroundColor = Color.Blue
                                showMenu = false
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Verde") },
                            onClick = {
                                backgroundColor = Color.Green
                                showMenu = false
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Restaurar") },
                            onClick = {
                                backgroundColor = Color.White
                                showMenu = false
                            }
                        )
                    }
                }
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        "Mantén presionado en cualquier parte de la pantalla para ver el menú contextual y cambiar el fondo.",
                        style = MaterialTheme.typography.headlineSmall,
                        color = contentColorFor(backgroundColor),
                        modifier = Modifier.padding(bottom = 16.dp)
                    )

                    Spacer(modifier = Modifier.height(40.dp))

                    Button(
                        onClick = {
                            navController.navigate("menu") {
                               popUpTo("menu") { inclusive = true }
                            }
                        },
                        modifier = Modifier.fillMaxWidth(0.6f)
                    ) {
                        Text("Volver al Menú")
                    }
                }
            }
        }
    )
}
