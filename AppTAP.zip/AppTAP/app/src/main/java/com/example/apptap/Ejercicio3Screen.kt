package com.example.apptap.ui.ejercicios

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Ejercicio3Screen(navController: NavController) {
    var backgroundColor by remember { mutableStateOf(Color.White) }

    var showMenu by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Ejercicio 3 : Cambio de Fondo") },
                actions = {
                    IconButton(onClick = { showMenu = !showMenu }) {
                        Icon(Icons.Default.MoreVert, contentDescription = "Menú de Opciones")
                    }

                    DropdownMenu(
                        expanded = showMenu,
                        onDismissRequest = { showMenu = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("Verde") },
                            onClick = {
                                backgroundColor = Color.Green
                                showMenu = false
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Azul") },
                            onClick = {
                                backgroundColor = Color.Blue
                                showMenu = false
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Rojo") },
                            onClick = {
                                backgroundColor = Color.Red
                                showMenu = false
                            }
                        )
                        // Opcional: Para volver al color original o blanco
                        DropdownMenuItem(
                            text = { Text("Restaurar") },
                            onClick = {
                                backgroundColor = Color.White
                                showMenu = false
                            }
                        )
                    }
                }
            )
        },
        content = { paddingValues ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .background(backgroundColor),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "¡El color de fondo cambiará con las opciones del menú!",
                    style = MaterialTheme.typography.headlineSmall,
                    color = contentColorFor(backgroundColor),
                    modifier = Modifier.padding(16.dp)
                )

                Spacer(modifier = Modifier.height(40.dp))

                // Botón para volver al menú principal
                Button(
                    onClick = {
                        navController.navigate("menu") {
                            popUpTo("menu") { inclusive = true }
                        }
                    },
                    modifier = Modifier.fillMaxWidth(0.6f)
                ) {
                    Text("Volver al Menú")
                }
            }
        }
    )
}

@Composable
fun contentColorFor(backgroundColor: Color): Color {
    return if (backgroundColor == Color.Black || backgroundColor == Color.Blue || backgroundColor == Color.Red) {
        Color.White
    } else {
        Color.Black
    }
}